# INSTALAR — Estudo BET completo em PT pelo motor de geometria real (sem os 20–30 min de leitura IA)

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Branch `claude/bet-geometria-real`, commit `22ad599`. Aplica-se POR CIMA de «imagens-processo» (344afd7).

## Problema (produção, 20/11, depois do deploy)
Estudo parado > 20 min em «Leitura dos desenhos por IA e levantamento do modelo do edifício» = o MOTOR ANTERIOR (bet_core),
cuja leitura IA tem prazo de 30 min. O motor de geometria real só era usado quando a planta NÃO era retangular (ou se o
anterior acabasse por pedir a geometria real, já depois da leitura longa). Se o motor de geometria real falhava, o
utilizador não via porquê.

## Correção
- PT: o estudo completo usa SEMPRE primeiro o motor de geometria real (qualquer forma, 1 piso) — ~3–6 min.
- Edifício de vários pisos ou geometria ilegível → volta ao motor anterior, com o MOTIVO visível no passo do estudo
  («Motor de geometria real: … — a usar o motor anterior») e guardado em `geo_engine_error` no job.
- Kill-switch: `BET_GEO_PT_ALL=0` (volta ao comportamento anterior: só plantas não retangulares), `BET_GEO_ENGINE=0`.

## 0. Diagnóstico (só leitura) — se tiveres acesso aos logs de PRODUÇÃO
`grep -E "bet_geo|bet study|reading timed out" <log de produção> | tail -40` — se não houver acesso a produção, dizê-lo.

## 1. Patch
`grep -q "BET_GEO_PT_ALL" backend/engines/bet_geo/run.py && echo "JÁ APLICADO" || echo "-> aplicar"`
`sha256sum rota-geo-DIFERENCIAL.patch` → `32887375e316beabef001c915f09fb708575500804ad0db9f7b66c2d4a1ba905`
`git apply --check rota-geo-DIFERENCIAL.patch && git apply rota-geo-DIFERENCIAL.patch`
Ficheiros: `engines/bet_geo/run.py`, `tests/test_bet_geo.py`. Nenhum T1-T8.

## 2. Testes (em segundo plano com setsid nohup, ~4–7 min no pod)
mesma lista que «imagens-processo» → esperado **134 passed, 1 skipped** (local: 133 + 1 do pod, como antes).

## 3. Restart + /api/health 200. Teste real em preview: dossier 261 no Assistente → passo «A ler a geometria real das plantas…»
(e NÃO «Leitura dos desenhos por IA…») e estudo concluído em < 10 min. Reportar o tempo.
Deploy só com o OK do Martinho.
