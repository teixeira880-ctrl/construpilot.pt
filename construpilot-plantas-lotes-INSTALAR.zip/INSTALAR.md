# INSTALAR — Plantas por lote depois do estudo de geometria real + estudo completo nunca volta ao motor anterior

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Branch `claude/bet-geometria-real`, commit `a72424a`. Aplica-se POR CIMA de «imagens-no-fim» (d8cc695).

## Causa encontrada (preview, 20/11)
A mensagem «Use as peças de referência verificadas. O motor de execução não suporta este contorno» NÃO vinha
da leitura das plantas: vinha da ferramenta `generate_bet_lot_plans` (plantas por lote) chamada pelo Assistente
DEPOIS do estudo. O estudo de geometria real grava `execution_verified=False` (a validar pelos técnicos) e essa
ferramenta interpretava isso como «contorno não suportado».

## Correção
1. `assistant_tool._lot_plans`: se o último estudo é de geometria real (`geo_engine`), devolve o conjunto
   «Desenhos de execução» já entregue e as folhas por lote (EL01/EL02, AG01, VT01, AQ01/AQ02, A02–A04, E02/E03/GO-01..03).
2. `bet_geo/run.py`: cada etapa do estudo completo é protegida (cortes, divisões, resumo, passo final).
   Se alguma rebentar, sai o conjunto de estrutura (nota de cálculo, plantas, Excel, DXF) com aviso visível —
   nunca mais volta ao motor anterior depois de ter lido a geometria.

## Ficheiros
- backend/engines/bet_core/assistant_tool.py
- backend/engines/bet_geo/run.py
- backend/tests/test_bet_geo.py
- backend/tests/test_geo_lot_plans.py (novo)

## Instalação
```
cd /app && git apply --check plantas-lotes-DIFERENCIAL.patch && git apply plantas-lotes-DIFERENCIAL.patch
```
Testes: lista «imagens-no-fim» + `tests/test_geo_lot_plans.py` → esperado **138 passed, 1 skipped**.
Restart backend. Deploy: AGUARDA_MARTINHO (sem estudos em curso).
