# INSTALAR — Apresentação sem retrocesso (logótipo + marca d'água da empresa em todas as folhas) + PDF em português + imagens 3D no orçamento + ZIP > 30 folhas

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Se algum passo falhar: PARAR e colar a saída bruta.

Branch de referência: `claude/bet-geometria-real`, commit `07a5179`. Aplica-se POR CIMA do pacote «estudo-completo» (já em preview). **SUBSTITUI o pacote «lingua-imagens-zip» (não instalar esse).**

## O que corrige (relatório do Martinho, 20/11)
1. **PDF em francês** num orçamento português (ex.: «Liste des matériaux», «Quantité», «Statut», «Renseignée»): a língua
   dos ficheiros vinha do ecrã (telemóvel em francês). Agora vem do DOCUMENTO e da EMPRESA (empresa PT → português);
   só um ecrã em inglês/ucraniano continua a mandar.
2. **Imagens 3D não saíam no orçamento**: as variáveis `CP_3D_IMAGES` / `QUOTE_HOUSE_PHOTO` nunca foram definidas
   (cartão de secrets por preencher) e o código tinha as imagens DESLIGADAS por defeito. Agora estão LIGADAS por defeito
   (motores internos, sem IA, sem custos); espera do 1.º PDF 90 s por defeito. Desligar sem deploy: `CP_3D_IMAGES=0`.
   → **Já não é preciso preencher as 5 variáveis do cartão** (podem ficar vazias). `STUDY_IMG_WAIT` continua opcional (240 por defeito).
3. **ZIP para PDF com mais de 30 folhas**: o processo de estudo, os desenhos e os PDF do orçamento/medição/dossier
   económico com mais de 30 folhas trazem também um ZIP (PDF completo + partes de 30 folhas no máximo).

4. **Selo/marca d'água da empresa e apresentação (0 retrocesso)**: todos os PDF do estudo completo (processo, desenhos,
   térmico REH, custo-benefício, especialidades, nota de estrutura) passam pelo MESMO acabamento que os orçamentos:
   capa com a imagem real do edifício e indicadores, índice, logótipo da empresa no rodapé, MARCA D'ÁGUA da empresa em
   todas as folhas e numeração. O carimbo de cada desenho A3 leva o logótipo, nome e contactos da empresa e a imagem real
   da casa (como os desenhos de execução de referência). O branding da empresa passa agora para o motor de geometria real.

## 1. Patch
```bash
cd /app
grep -q "exec_sheets" backend/engines/bet_geo/drawings.py && echo "-> DIFERENCIAL" || echo "-> CUMULATIVO"
```
- **DIFERENCIAL** (estudo-completo já aplicado):
  `sha256sum apresentacao-DIFERENCIAL.patch` → `6a34b30cd2fe638ee41622457931da929489079b42ba510b5be352609156a8a4`
  `git apply --check apresentacao-DIFERENCIAL.patch && git apply apresentacao-DIFERENCIAL.patch`
- **CUMULATIVO** (nada de bet_geo aplicado):
  `sha256sum apresentacao-CUMULATIVO.patch` → `bd02ac9e64da0c9d99d9661173decbf17e0ef80bfcc80f316ffb345a6b391245`
  `git apply --check apresentacao-CUMULATIVO.patch && git apply apresentacao-CUMULATIVO.patch`

Ficheiros tocados pelo DIFERENCIAL (11): `engines/assistant_quote_exports.py`, `engines/bet_core/assistant_tool.py`,
`engines/bet_geo/run.py`, `engines/bet_geo/drawings.py`, `engines/bet_geo/outputs.py`, `engines/images3d.py`,
`engines/quote_building.py`, novo `engines/pdf_parts.py`, `tests/test_pdf_parts_lang.py` (novo), `tests/test_quote_house_3d.py`,
`tests/test_bet_geo_completo.py`. Nenhum ficheiro protegido T1-T8.

## 2. Testes
```bash
cd /app/backend
python -m pytest tests/test_pdf_parts_lang.py tests/test_assistant_quote_exports.py tests/test_bet_geo_completo.py tests/test_kling_quote_geo.py tests/test_quote_house_3d.py tests/test_photoreal.py tests/test_pdf_premium.py tests/test_bet_geo.py tests/bet_core/test_doc_loader_pt.py tests/bet_core/test_cad_in_study.py tests/bet_core/test_assistant_tool.py tests/test_bet_geometry_review.py tests/test_bet_routing_heartbeat.py tests/test_bet_fase1_pt.py tests/test_bet_strip_foundations.py tests/test_bet_prazo_leitura.py -n 0 -q
```
Esperado: **130 passed, 1 skipped**.

## 3. Restart + teste real
`sudo supervisorctl restart backend` → `/api/health` 200.
Conta PT com o telemóvel em francês → Assistente → orçamento de uma moradia com estudo BET → descarregar orçamento e medição:
cabeçalhos em português («Lista de materiais», «Quantidade», «Estado») e imagem 3D na capa.
Estudo completo do dossier 261 → cada PDF com capa (imagem real), logótipo e marca d'água da empresa em todas as folhas; carimbo dos desenhos com o logótipo; além dos PDF, um ZIP «Processo de estudo … ZIP (completo + partes de 30 folhas)».

## 4. Relatório
Patch aplicado, testes, capturas (capa do orçamento com imagem, página da lista de materiais em PT, conteúdo do ZIP).
Deploy só depois do OK do Martinho — **as correções só chegam aos utilizadores depois do Deploy para produção**.
