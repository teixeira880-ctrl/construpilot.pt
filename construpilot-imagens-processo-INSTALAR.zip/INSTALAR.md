# INSTALAR — Imagens 3D num processo separado (o estudo BET deixa de ficar preso no passo «imagens»)

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Se algum passo falhar: PARAR e colar a saída bruta.

Branch de referência: `claude/bet-geometria-real`, commit `344afd7`. Aplica-se POR CIMA do pacote «apresentacao» (07a5179, já em preview).

## Problema (teste do Martinho, 20/11)
Estudo BET completo parado mais de 20 min em «A calcular as imagens reais do edifício». Causa: o Mitsuba corria em threads
do próprio backend e prende o GIL em blocos de vários segundos; com as 4 vistas HD o ciclo de eventos quase não avançava
(estudo parado e servidor lento para todos).

## Correção
- Cada renderização física corre num **subprocesso** (`engines/render_worker.py`) com prazo; se o prazo acabar o processo é
  terminado. No máximo 1 renderização de cada vez (`PBR_MAX_PARALLEL`, opcional).
- O estudo **já não espera pelas 4 vistas HD**: usa a cache se existir; senão faz só a perspetiva principal 1600×900
  (prazo 150 s) + vistas calculadas, e continua. As vistas HD do orçamento seguem em segundo plano.
- Guarda global: o estudo nunca espera mais de 240 s pelas imagens (`STUDY_IMG_GUARD`, opcional).
Medido: ciclo de eventos livre durante a renderização (pausa máx. 0,05 s, antes 3,2 s).

## 0. Antes de aplicar — diagnóstico do estudo preso (só leitura)
```bash
grep -E "bet_geo|house renders|pbr render|Traceback" /var/log/supervisor/backend.err.log | tail -40
ps aux --sort=-%cpu | head -8
```
Colar a saída no relatório.

## 1. Patch
```bash
cd /app
grep -q "render_worker" backend/engines/quote_building.py && echo "JÁ APLICADO" || echo "-> DIFERENCIAL"
```
- **DIFERENCIAL**: `sha256sum imagens-processo-DIFERENCIAL.patch` → `de773b190be0406d33717883bfeb9392be77c938e51a69a9c73dc66113b18fd9`
  `git apply --check imagens-processo-DIFERENCIAL.patch && git apply imagens-processo-DIFERENCIAL.patch`
- **CUMULATIVO** (só se nada de bet_geo estiver aplicado): `sha256sum imagens-processo-CUMULATIVO.patch` → `d24d62c0d28d0a2219bc9b1ad64eb2b3c834b9e716329f5c1f66afa8c91588ad`

Ficheiros: `engines/bet_geo/run.py`, `engines/quote_building.py`, novo `engines/render_worker.py`, `tests/test_kling_quote_geo.py`,
novo `tests/test_render_worker.py`. Nenhum ficheiro protegido T1-T8.

## 2. Testes (correr em segundo plano: demoram ~3–5 min no pod)
```bash
cd /app/backend
nohup python -m pytest tests/test_render_worker.py tests/test_pdf_parts_lang.py tests/test_assistant_quote_exports.py tests/test_bet_geo_completo.py tests/test_kling_quote_geo.py tests/test_quote_house_3d.py tests/test_photoreal.py tests/test_pdf_premium.py tests/test_bet_geo.py tests/bet_core/test_doc_loader_pt.py tests/bet_core/test_cad_in_study.py tests/bet_core/test_assistant_tool.py tests/test_bet_geometry_review.py tests/test_bet_routing_heartbeat.py tests/test_bet_fase1_pt.py tests/test_bet_strip_foundations.py tests/test_bet_prazo_leitura.py -n 0 -q > /tmp/imgproc_pytest.log 2>&1 &
# depois: tail -3 /tmp/imgproc_pytest.log
```
Esperado: **133 passed, 1 skipped** (no pod pode dar +1 como antes).

## 3. Restart
`sudo supervisorctl restart backend` → `/api/health` 200. (O restart termina o estudo que estava preso: relançar o estudo no Assistente.)
Verificar que o subprocesso funciona no pod:
```bash
cd /app/backend && python - <<'PY'
import asyncio, time
from shapely.geometry import Polygon
from engines import render_worker
from engines.bet_geo.model import Building
g = {**Building(footprint=Polygon([(0,0),(12,0),(12,8),(0,8)]), roof_level=3.2).to_dict(), "slab_h": 0.22}
t = time.time(); png = asyncio.run(render_worker.render("geo", g, "main", 1600, 900, 24, 150))
print("ok" if png else "FALHOU", round(time.time() - t, 1), "s")
PY
```
Reportar o tempo (é o tempo da imagem principal de cada estudo).

## 4. Relatório
Diagnóstico §0, patch, testes, tempo da renderização §3. Deploy só depois do OK do Martinho.
