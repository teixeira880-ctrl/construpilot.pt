# INSTALAR — Estudo BET entregue SEM esperar por imagens (imagens HD só no fim, depois da entrega)

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Branch `claude/bet-geometria-real`, commit `d8cc695`. Aplica-se POR CIMA de «rota-geo» (22ad599).

## Decisão do Martinho (20/11)
«Se são as imagens que bloqueiam, anula-as ou passa-as no fim do estudo e da entrega dos documentos.»
- O estudo NÃO faz nenhuma renderização física: as capas dos PDF usam as vistas calculadas da geometria real (instantâneas).
- Medido localmente no dossier 261: estudo completo em ~62 s (sem a latência da IA), 1,1 GB de RAM.
- O orçamento oficial do estudo também não espera pelas imagens.
- DEPOIS de tudo entregue: as 4 vistas HD são calculadas em segundo plano (processo separado); quando ficam prontas são
  juntadas ao estudo («Imagem real HD — …») e o orçamento oficial é refeito com elas (nova versão dos ficheiros).
  Se o servidor reiniciar entretanto, só se perdem as imagens HD — os documentos já estão entregues.
- Kill-switch: `STUDY_LATE_IMAGES=0` (sem imagens HD no fim).

**ATENÇÃO deploy:** um deploy reinicia o servidor e interrompe os estudos que estiverem a correr nesse momento
(foi o «interrompido (reinício do servidor)» das 15:28). Fazer o deploy sem estudos em curso.

## 1. Patch
`grep -q "_late_images" backend/engines/bet_geo/run.py && echo "JÁ APLICADO" || echo "-> aplicar"`
`sha256sum imagens-no-fim-DIFERENCIAL.patch` → `bcb0f162c3732ca0028fa11703c3d30fec165f531b40054fe47cf918266b5905`
`git apply --check imagens-no-fim-DIFERENCIAL.patch && git apply imagens-no-fim-DIFERENCIAL.patch`
Ficheiros: `engines/bet_geo/run.py`, `engines/quote_building.py`, novo `tests/test_bet_geo_late.py`. Nenhum T1-T8.

## 2. Testes (setsid nohup em segundo plano): lista de «rota-geo» + `tests/test_bet_geo_late.py`
→ esperado **136 passed, 1 skipped** (local 135 + 1 do pod, como antes).

## 3. Restart + /api/health 200. Deploy só com o OK do Martinho e sem estudos em curso.
