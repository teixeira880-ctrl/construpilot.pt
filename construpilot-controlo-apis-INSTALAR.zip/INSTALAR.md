# INSTALAR — Admin → IA: controlo central de todas as IA e API

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Branch `claude/bet-geometria-real`, commit `492b26c`. Aplica-se POR CIMA de «plantas-lotes» (a72424a).

## O que faz
Em Admin → IA, novo bloco «Todas as IA e API do ConstruPilot» (16 fornecedores: Emergent, OpenAI, Anthropic, Gemini,
Perplexity, Tavily, Apify, Kling, Runway, ElevenLabs, LiveKit, HeyCatch, CloudConvert, Google Maps, Twilio, Resend):
- interruptor ligar/desligar por API — desligar retira a chave do processo SEM a apagar dos Secrets; religar devolve-a;
  estado guardado em app_settings «api_control», reaplicado no arranque e a cada 30 s;
- Claude / Gemini desligados = não usados nem pela chave Emergent; pelo menos uma IA de conversa fica ligada;
  a chave universal Emergent não se desliga (serve também o armazenamento de ficheiros);
- crédito/saldo lido no fornecedor quando ele o publica (ElevenLabs, Runway, CloudConvert, Apify, Twilio, Kling;
  OpenAI e Anthropic: gasto do mês só com OPENAI_ADMIN_KEY / ANTHROPIC_ADMIN_KEY opcionais nos Secrets);
  os outros: link para a consola de faturação; nunca mostra a chave;
- chamadas IA do mês por fornecedor (nova coleção ai_usage_monthly), limite €/mês anotado, histórico das alterações.

## Ficheiros
backend/engines/api_control.py (novo), backend/engines/ai.py, backend/engines/llm_keys.py,
backend/engines/assistant_fallback.py, backend/routes/admin.py, backend/tests/test_api_control.py (novo),
frontend/src/components/ApiControlPanel.jsx (novo), frontend/src/components/AiModelTab.jsx

## Instalação
```
cd /app && git apply --check controlo-apis-DIFERENCIAL.patch && git apply controlo-apis-DIFERENCIAL.patch
```
Testes: lista «plantas-lotes» + tests/test_api_control.py tests/test_openai_key_breaker.py tests/test_assistant_claude_principal.py
→ esperado 138 + 5 novos + os dois existentes a passar. Restart backend E frontend.
Verificar no preview: Admin → IA mostra o bloco, 16 linhas, interruptor Emergent bloqueado.
Kill-switch: nenhum necessário — com tudo ligado o comportamento é o anterior.
Deploy: AGUARDA_MARTINHO (sem estudos em curso).
