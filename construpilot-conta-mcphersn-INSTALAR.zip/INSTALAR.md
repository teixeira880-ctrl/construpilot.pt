# INSTALAR — Conta Pro Business mcphersn@gmail.com

Código escrito pelo Claude. **Emergent: só instalar, testar e reportar. Não alterar código.**
Branch `claude/bet-geometria-real`, commit `ebcf9e2`. Aplica-se POR CIMA de «controlo-apis» (492b26c).

Acrescenta a conta a core/client_grants.py (mesmo mecanismo da conta Rui Filipe): criada no arranque,
Pro Business (pro_business_yearly) durante 365 dias, must_change_password=True.
A palavra-passe NÃO está no código: lida do Secret `GRANT_MCPHERSN_PASSWORD`, posto pelo Martinho.
Sem esse Secret a conta é saltada (log «variável GRANT_MCPHERSN_PASSWORD ausente»).
Conta já existente → a palavra-passe nunca é reescrita; só é garantido o Pro Business.

Instalação: git apply --check / git apply conta-mcphersn-DIFERENCIAL.patch ; pytest tests/test_client_grants.py (6 passed) ; restart backend.
Deploy: AGUARDA_MARTINHO.
